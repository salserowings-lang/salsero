from pydantic import BaseModel
from decimal import Decimal
from typing import Optional, List
from datetime import datetime

class ProductoBase(BaseModel):
    nombre: str
    descripcion: Optional[str] = None
    precio: Decimal
    categoria: str
    stock: int = 0
    imagen: Optional[str] = None

class ProductoCreate(ProductoBase):
    pass

class Producto(ProductoBase):
    id: int

    class Config:
        from_attributes = True

class ItemPedido(BaseModel):
    producto_id: int
    nombre: str
    cantidad: int
    precio_unitario: Decimal
    subtotal: Decimal

class PedidoCreate(BaseModel):
    nombre_cliente: str
    telefono: str
    direccion: str
    referencia: Optional[str] = None
    latitud: Optional[float] = None
    longitud: Optional[float] = None
    items: List[ItemPedido]
    total: Decimal

class Pedido(PedidoCreate):
    id: int
    fecha: datetime
    estado: str

    class Config:
        from_attributes = True
